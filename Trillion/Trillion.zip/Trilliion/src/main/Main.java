package main;

import javax.swing.UIManager;
import ui.JFrameGame;
import ui.WaitFrame;
import ui.config.FrameConfig;
public class Main {
	static {
		
	try {
		//ˮ��������
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (Exception e1) {			
		}
	}
	public static void main(String[] args) {
		WaitFrame wFrame = new WaitFrame();
		JFrameGame frame = new JFrameGame();
		new FrameConfig(wFrame,frame);
	}
}