package model;

public interface Port {

	public abstract void updata(long tick);
	
	public abstract void startGameInit();
}