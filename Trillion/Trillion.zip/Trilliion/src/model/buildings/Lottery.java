package model.buildings;

import context.GameState;

public class Lottery extends Building {
	
	public Lottery(int posX, int posY) {

		super(posX, posY);

		this.name = "��͸";

	}
	public int getEvent() {

		return GameState.LOTTERY_EVENT;

	}

}