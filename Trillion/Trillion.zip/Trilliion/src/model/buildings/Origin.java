package model.buildings;

import context.GameState;

public class Origin extends Building {


	private int passReward;


	private int reward;

	public Origin(int posX, int posY) {

		super(posX, posY);

		this.name = "���";

		this.reward = 500;

		this.passReward = 200;

	}
	public int getEvent() {

		return GameState.ORIGIN_EVENT;

	}

	public int getPassReward() {

		return passReward;

	}

	public int getReward() {

		return reward;

	}
	public int passEvent() {

		return GameState.ORIGIN_PASS_EVENT;

	}
}