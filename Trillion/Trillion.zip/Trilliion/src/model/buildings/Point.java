package model.buildings;

import context.GameState;

public class Point extends Building {

	private int point;

	public Point(int posX, int posY, int point) {

		super(posX, posY);

		this.name = point + "���λ";

		this.point = point;

	}

	public int getPoint() {

		return point;

	}

	public int getEvent() {

		return GameState.POINT_EVENT;

	}

}