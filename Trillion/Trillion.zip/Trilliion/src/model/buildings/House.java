package model.buildings;

import context.GameState;

public class House extends Building {



	private int upPrice;

	private String[] nameString = { "�յ�", "ƽ��", "����", "�̳�", "��ҵ��¥", "Ħ���¥" };

	public House(int posX, int posY) {

		super(posX, posY);

		this.maxLevel = 5;

	}

	public int getUpLevelPrice() {

		if (this.level == 0) {

			this.upPrice = 500;

		} else {

			this.upPrice = 1000 * this.level;

		}

		return upPrice;

	}

	public int getAllPrice() {

		int price = 0;

		for (int i = 0; i <= level; i++) {

			if (this.level == 0) {

				price +=500;

			} else {

				price += 1000 * i;

			}

		}

		return price;

	}

	public int getRevenue() {

		this.revenue = this.level * (int) (Math.random() * 1000)

				+ (this.level * 300);

		return revenue;

	}



	public String getName() {

		return this.nameString[this.level];

	}

	public String getUpName() {

		if (this.level >= this.nameString.length - 1) {

			return "null";

		}

		return this.nameString[this.level + 1];

	}

	public int getEvent() {

		return GameState.HUOSE_EVENT;

	}

}