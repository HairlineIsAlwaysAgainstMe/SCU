package model.card;

import context.GameState;

import model.PlayerModel;

public class AveragerPoorCard extends Card {

	public AveragerPoorCard(PlayerModel owner) {

		super(owner);

		this.name = "AveragerPoorCard";

		this.cName = "��ƶ��";

		this.price = 200;

	}
	public int useCard() {

		return GameState.CARD_AVERAGERPOOR;

	}
}