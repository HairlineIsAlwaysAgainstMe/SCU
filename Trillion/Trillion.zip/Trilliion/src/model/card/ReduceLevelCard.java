package model.card;

import context.GameState;

import model.PlayerModel;

public class ReduceLevelCard extends Card{

	public ReduceLevelCard(PlayerModel owner) {

		super(owner);

		this.name = "ReduceLevelCard";

		this.cName = "������";

		this.price = 30;

	}
	public int useCard() {

		return GameState.CARD_REDUCELEVEL;

		}
}