package model.card;

import context.GameState;

import model.PlayerModel;

public class HaveCard extends Card {

	public HaveCard(PlayerModel owner) {

		super(owner);

		this.name = "HaveCard";

		this.cName = "���ؿ�";

		this.price = 50;

	}

	public int useCard() {

		return GameState.CARD_HAVE;

	}
}