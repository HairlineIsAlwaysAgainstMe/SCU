package model.card;

import context.GameState;

import model.PlayerModel;

public class CrossingCard extends Card{

	public CrossingCard(PlayerModel owner) {

		super(owner);

		this.name = "CrossingCard";

		this.cName = "�޻���";

		this.price = 120;

	}
	public int useCard() {

		return GameState.CARD_CROSSING;
	}
}