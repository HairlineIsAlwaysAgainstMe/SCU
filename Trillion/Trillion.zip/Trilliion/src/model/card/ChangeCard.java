package model.card;

import context.GameState;

import model.PlayerModel;

public class ChangeCard extends Card {

	public ChangeCard(PlayerModel owner) {

		super(owner);

		this.name = "ChangeCard";

		this.cName = "���ݿ�";

		this.price = 70;

	}
	public int useCard() {

		return GameState.CARD_CHANGE;

	}
}