package model.card;

import context.GameState;

import model.PlayerModel;


public class StopCard extends Card{

	public StopCard(PlayerModel owner) {

		super(owner);

		this.name = "StopCard";

		this.cName ="ͣ����";

		this.price = 50;

	}

	public int useCard() {

		return GameState.CARD_STOP;

	}

	public int cardBuff(){

		return GameState.CARD_BUFF_STOP;

	}

}