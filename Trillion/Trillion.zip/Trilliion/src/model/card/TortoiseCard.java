package model.card;

import context.GameState;

import model.PlayerModel;

public class TortoiseCard extends Card {

	private int life = 3;

	public TortoiseCard(PlayerModel owner) {

		super(owner);

		this.name = "TortoiseCard";

		this.cName = "�ڹ꿨";

		this.price = 50;

	}
	public int useCard() {

		return GameState.CARD_TORTOISE;

	}
	public int getLife() {

		return life;

	}

	public void setLife(int life) {

		this.life = life;

	}

	public int cardBuff() {

		return GameState.CARD_BUFF_TORTOISE;

	}

}