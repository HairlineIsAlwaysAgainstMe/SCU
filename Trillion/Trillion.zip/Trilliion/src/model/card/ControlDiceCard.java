package model.card;

import context.GameState;

import model.PlayerModel;

public class ControlDiceCard extends Card{

	int diceNumber;	

	public ControlDiceCard(PlayerModel owner) {

		super(owner);

		this.name = "ControlDiceCard";

		this.cName = "ң�����ӿ�";

		this.price = 30;

	}

	public int useCard() {

		return GameState.CARD_CONTROLDICE;

	}

}