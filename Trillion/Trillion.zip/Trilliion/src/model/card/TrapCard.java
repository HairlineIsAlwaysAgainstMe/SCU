package model.card;

import context.GameState;

import model.PlayerModel;

public class TrapCard extends Card {

	public TrapCard(PlayerModel owner) {

		super(owner);

		this.name = "TrapCard";

		this.cName = "�ݺ���";

		this.price = 120;

	}

	public int useCard() {

		return GameState.CARD_TRAP;

	}



}