package model.card;

import context.GameState;

import model.PlayerModel;

public class TallageCard extends Card{

	public TallageCard(PlayerModel owner) {

		super(owner);

		this.name = "TallageCard";

		this.cName = "��˰��";

		this.price = 100;

	}
	public int useCard() {

		return GameState.CARD_TALLAGE;

	}
}